package com.storybridge.pro;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.os.*;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;
import java.util.*;

public class StoryAutomationService extends AccessibilityService {
    private final Handler h=new Handler(Looper.getMainLooper()); private boolean scheduled=false;
    private final String[] SHARE={"Compartilhar","Share","Enviar"};
    private final String[] ADD={"Adicionar ao story","Adicionar ao seu story","Add to story","Add post to your story","Add reel to your story"};
    private final String[] STICKERS={"Figurinhas","Stickers","Adesivos"};
    private final String[] MENTION={"MENÇÃO","Menção","Mention","MENTION"};
    private final String[] DONE={"Concluir","Done"};
    private final String[] YOUR_STORY={"Seu story","Seu Story","Your story","Compartilhar"};
    @Override public void onAccessibilityEvent(AccessibilityEvent e){if(e.getPackageName()==null||!"com.instagram.android".contentEquals(e.getPackageName()))return;SharedPreferences p=JobStore.get(this);if(!p.getBoolean("pending",false)||scheduled)return; scheduleNext();}
    @Override public void onInterrupt(){}
    void scheduleNext(){SharedPreferences p=JobStore.get(this);int min=p.getInt("min",6),max=p.getInt("max",14);long delay=(min+new Random().nextInt(Math.max(1,max-min+1)))*1000L;scheduled=true;h.postDelayed(()->{scheduled=false;runStep();},delay);}
    void runStep(){SharedPreferences p=JobStore.get(this);if(!p.getBoolean("pending",false))return;AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null){scheduleNext();return;}int step=p.getInt("step",0);boolean ok=false;
        if(step==0){ok=clickAny(root,SHARE);if(ok){JobStore.step(this,1);toast("Compartilhar aberto");}}
        else if(step==1){ok=clickAny(root,ADD);if(ok){JobStore.step(this,2);toast("Editor do Story aberto");}}
        else if(step==2){String m=p.getString("mention","");if(m==null||m.isEmpty()){JobStore.step(this,5);scheduleNext();return;}ok=clickAny(root,STICKERS);if(ok){JobStore.step(this,3);toast("Abrindo figurinhas");}else if(tryTextMention(root,m)){JobStore.step(this,5);ok=true;}}
        else if(step==3){ok=clickAny(root,MENTION);if(ok){JobStore.step(this,4);toast("Adicionando menção");}}
        else if(step==4){String m=p.getString("mention","");ok=setFirstEditable(root,m);if(ok){clickAny(root,DONE);JobStore.step(this,5);}}
        else if(step==5){ok=clickAny(root,YOUR_STORY);if(ok){JobStore.clear(this);toast("Story enviado");return;}}
        if(!ok)scheduleNext();
    }
    boolean tryTextMention(AccessibilityNodeInfo r,String m){if(!clickAny(r,new String[]{"Texto","Text","Aa"}))return false;h.postDelayed(()->{AccessibilityNodeInfo x=getRootInActiveWindow();if(x!=null){setFirstEditable(x,"@"+m);clickAny(x,DONE);}},900);return true;}
    boolean setFirstEditable(AccessibilityNodeInfo n,String value){if(n==null)return false;if(n.isEditable()){Bundle b=new Bundle();b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,value);return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b);}for(int i=0;i<n.getChildCount();i++)if(setFirstEditable(n.getChild(i),value))return true;return false;}
    boolean clickAny(AccessibilityNodeInfo root,String[] labels){for(String s:labels){List<AccessibilityNodeInfo> xs=root.findAccessibilityNodeInfosByText(s);for(AccessibilityNodeInfo n:xs)if(clickNode(n))return true;if(scanDesc(root,s.toLowerCase(Locale.ROOT)))return true;}return false;}
    boolean scanDesc(AccessibilityNodeInfo n,String needle){if(n==null)return false;CharSequence d=n.getContentDescription();if(d!=null&&d.toString().toLowerCase(Locale.ROOT).contains(needle)&&clickNode(n))return true;for(int i=0;i<n.getChildCount();i++)if(scanDesc(n.getChild(i),needle))return true;return false;}
    boolean clickNode(AccessibilityNodeInfo n){AccessibilityNodeInfo x=n;while(x!=null){if(x.isClickable())return x.performAction(AccessibilityNodeInfo.ACTION_CLICK);x=x.getParent();}return false;}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
