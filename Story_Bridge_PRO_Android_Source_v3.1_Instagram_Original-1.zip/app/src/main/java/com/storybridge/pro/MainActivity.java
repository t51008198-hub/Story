package com.storybridge.pro;

import android.app.Activity;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.content.pm.PackageManager;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    LinearLayout root; EditText url,mention,min,max; TextView state;
    int purple=Color.rgb(126,78,255), card=Color.rgb(22,24,31), muted=Color.rgb(166,170,182);
    @Override public void onCreate(Bundle b){super.onCreate(b); build(); handleIntent(getIntent());}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i); setIntent(i); handleIntent(i);}
    TextView text(String s,int sp,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextColor(Color.WHITE);v.setTextSize(sp);if(bold)v.setTypeface(null,1);return v;}
    EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.rgb(110,114,126));e.setTextColor(Color.WHITE);e.setBackgroundColor(Color.rgb(14,16,21));e.setPadding(24,6,24,6);e.setSingleLine(true);return e;}
    void build(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(28,28,28,28);root.setBackgroundResource(com.storybridge.pro.R.drawable.bg_main);
        ScrollView sc=new ScrollView(this);sc.addView(root);setContentView(sc);
        TextView title=text("Story Bridge PRO",28,true);root.addView(title);
        TextView sub=text("Instagram • Conta pessoal • Fluxo nativo",14,false);sub.setTextColor(muted);root.addView(sub);
        addSpace(22); addLabel("Link do post ou Reel"); url=input("https://www.instagram.com/p/...");root.addView(url,lp(-1,58));
        addSpace(16);addLabel("Mencionar no Story (opcional)");mention=input("@usuario");root.addView(mention,lp(-1,58));
        addSpace(16);addLabel("Tempo aleatório entre ações");
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);min=input("Mín. s");max=input("Máx. s");row.addView(min,lp(0,58,1));addGap(row,10);row.addView(max,lp(0,58,1));root.addView(row);
        min.setText("6");max.setText("14");
        addSpace(20); state=text("● Pronto",13,true);state.setTextColor(Color.rgb(87,230,144));root.addView(state);
        addSpace(14); Button enable=button("ATIVAR ACESSIBILIDADE",false);enable.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));root.addView(enable,lp(-1,58));
        addSpace(10);Button open=button("ABRIR INSTAGRAM ORIGINAL",false);open.setOnClickListener(v->openInstagramHome());root.addView(open,lp(-1,58));
        addSpace(10);Button start=button("ABRIR POST NO INSTAGRAM E INICIAR",true);start.setOnClickListener(v->startJob());root.addView(start,lp(-1,62));
        addSpace(16);TextView note=text("O serviço observa somente o app Instagram. Nenhuma senha, cookie ou token é coletado.",12,false);note.setTextColor(muted);root.addView(note);
    }
    void addLabel(String s){TextView t=text(s,14,true);root.addView(t);} void addSpace(int h){Space s=new Space(this);root.addView(s,new LinearLayout.LayoutParams(1,h));}
    void addGap(LinearLayout l,int w){Space s=new Space(this);l.addView(s,new LinearLayout.LayoutParams(w,1));}
    LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} LinearLayout.LayoutParams lp(int w,int h,float wt){return new LinearLayout.LayoutParams(w,h,wt);}
    Button button(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setBackgroundColor(primary?purple:Color.rgb(35,38,47));return b;}
    void handleIntent(Intent i){Uri d=i.getData(); if(d==null)return; if("setup".equals(d.getHost())){startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));return;} if(!"share".equals(d.getHost()))return;
        String u=d.getQueryParameter("url"),m=d.getQueryParameter("mention");int mi=parse(d.getQueryParameter("min"),6),ma=parse(d.getQueryParameter("max"),14);
        if(u!=null)url.setText(u);if(m!=null&&!m.isEmpty())mention.setText("@"+m);min.setText(String.valueOf(mi));max.setText(String.valueOf(ma));
        if("1".equals(d.getQueryParameter("autostart"))) startJob();
    }
    int parse(String s,int d){try{return Integer.parseInt(s);}catch(Exception e){return d;}}
    boolean instagramInstalled(){
        try{getPackageManager().getPackageInfo("com.instagram.android",0);return true;}catch(Exception e){return false;}
    }
    void openInstagramHome(){
        if(!instagramInstalled()){state.setText("● Instagram original não encontrado");state.setTextColor(Color.rgb(255,110,120));return;}
        try{
            Intent launch=getPackageManager().getLaunchIntentForPackage("com.instagram.android");
            if(launch==null)throw new Exception("Sem intent de abertura");
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
            state.setText("● Instagram original aberto");state.setTextColor(Color.rgb(87,230,144));
        }catch(Exception e){state.setText("● Não foi possível abrir o Instagram original");state.setTextColor(Color.rgb(255,110,120));}
    }
    void startJob(){String u=url.getText().toString().trim();if(!u.contains("instagram.com/")){state.setText("● Link inválido");state.setTextColor(Color.rgb(255,110,120));return;}int mi=parse(min.getText().toString(),6),ma=parse(max.getText().toString(),14);if(mi<2)mi=2;if(ma<mi)ma=mi;
        if(!instagramInstalled()){state.setText("● Instale o aplicativo original do Instagram");state.setTextColor(Color.rgb(255,110,120));return;}
        String m=mention.getText().toString().trim().replace("@","");JobStore.save(this,u,m,mi,ma);state.setText("● Abrindo a postagem no Instagram original…");state.setTextColor(Color.rgb(87,230,144));
        try{
            Intent x=new Intent(Intent.ACTION_VIEW,Uri.parse(u));
            x.setPackage("com.instagram.android");
            x.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(x);
        }catch(Exception e){state.setText("● Não foi possível abrir o Instagram original");state.setTextColor(Color.rgb(255,110,120));}
    }
}
