package com.storybridge.pro;

import android.content.Context;
import android.content.SharedPreferences;

public final class JobStore {
    private static final String P="storybridge_job";
    public static void save(Context c,String url,String mention,int min,int max){
        c.getSharedPreferences(P,Context.MODE_PRIVATE).edit().putString("url",url).putString("mention",mention)
          .putInt("min",min).putInt("max",max).putBoolean("pending",true).putInt("step",0).apply();
    }
    public static SharedPreferences get(Context c){return c.getSharedPreferences(P,Context.MODE_PRIVATE);}
    public static void step(Context c,int s){get(c).edit().putInt("step",s).apply();}
    public static void clear(Context c){get(c).edit().putBoolean("pending",false).putInt("step",0).apply();}
}
